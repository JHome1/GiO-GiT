cd ..
class=0
python trainer.py --REAL_CLASS=$class --USE_Baseline
